# Handoff: Queen Trivia — Home, Player Flow & Host Console

## What this is
A full visual redesign + rebrand of the live trivia app to **Queen Trivia**, covering three surfaces:

1. **Home / landing page** — public entry where players join by room code (`Queen Trivia Home.dc.html`).
2. **Player flow** — the mobile join → play → results journey (`Trivia Redesign.dc.html`, option `2a`).
3. **Host console** — the admin dashboard for building quizzes and running games live (`Host Console.dc.html`).

All three share one brand system (below). This is a **UI/UX refresh + rename** — reuse all existing data fetching, auth, sockets, routing, and API hooks. Do not change behavior.

> **Start here:** open `Start Here.dc.html` — a hub linking to every design. Each design page also has a persistent **☰ All designs** button (bottom-right) that returns to the hub.

## About the design files
These `*.dc.html` files are **design references created in HTML** — prototypes showing intended look, layout, copy, and interaction. They are **not production code**; they use a lightweight internal templating runtime, not React. Recreate them in the existing codebase (`@workspace/trivia-game`: Vite + React + TypeScript, Tailwind v4 + shadcn/ui, Manrope, wouter, framer-motion), mapping each screen onto existing pages/components and reusing the app's tokens and patterns.

---

## Brand system (applies to all three)

### Name & logo
- **Name:** Queen Trivia. Wordmark set in Manrope 800; often stacked **QUEEN** (yellow `#ffe500`) over **TRIVIA** (pink `#ff0080`).
- **Crown mark** — a flat geometric crown, inline SVG (no image asset), on a `0 0 100 84` viewBox:
  - Body path: `M8,66 L8,26 L30,46 L50,14 L70,46 L92,26 L92,66 Z` + base band `rect x=8 y=64 w=84 h=14 rx=4`, both filled pink `#ff0080`.
  - Three jewels: circles at `(8,24) r6`, `(50,12) r7.5`, `(92,24) r6`, filled yellow `#ffe500`.
  - Optional 3 base "gem holes": circles at x30/50/70 y71 r3.6, fill = background color at 0.4 opacity.
  - **Flat only** — no gradients, glows, or drop-shadows on the mark (client preference).

### Palette
Near-black surfaces + three neon accents. Prefer existing CSS tokens over hardcoded hex.

| Role | Hex | Use |
|---|---|---|
| Background | `#0d0f15` | app/page background (flat — no gradient hero) |
| Panel / card | `rgba(255,255,255,.03)` on bg; host panels `#0f1724` | cards, join panel |
| Border | `#2a2233` (player), `#232a38`/`#1b2740` (host) | card/panel borders |
| **Pink (primary)** | `#ff0080` | brand, primary/destructive-of-attention, "live" |
| **Yellow (accent)** | `#ffe500` | primary CTA, points/score, "go" |
| **Cyan (secondary)** | `#00ddff` | codes/info, correct-answer accent |
| Green | `#35d07f` | host: answered / correct / go-live |
| Red | `#ff6b6b` | host: end/destructive |
| Muted text | `#b7a8d0` (player) / `#9aa6bc` (host) | body |
| Dim text | `#66728a` | labels, eyebrows |

- **No heavy gradients.** Backgrounds are flat `#0d0f15`; accent fills are flat tints (e.g. `rgba(255,0,128,.1)`), not `linear-gradient`. (This replaced the earlier purple-gradient direction.)
- Numerals / codes: `ui-monospace` with `font-variant-numeric: tabular-nums`.

### Typography
`Manrope` (already bundled at `/fonts/manrope-*.otf`; prototypes load from Google Fonts for portability). Weights 300–800. Headlines 800 with tight tracking (`-.035em` on the big wordmark).

### Motion (subtle only)
- `twinkle` (opacity .35↔1) on the "live" dot and ambient sparkles.
- `floaty` (translateY ±8px) on the hero crown and floating accents.
- Screen/step transitions: fade + small slide (~300ms).

---

## 1. Home / landing page — `Queen Trivia Home.dc.html`
Public entry page. **Responsive (mobile + web).**

- **Nav:** crown + "Queen Trivia" left; "How it works" + "Host sign in" right (the text link hides < 680px).
- **Hero (front & center):** floating crown mark, then the huge stacked **QUEEN / TRIVIA** wordmark (fluid `clamp(46px,13vw,76px)`), tagline "Enter the code. Answer fast. Take the throne."
- **Join card:** bordered panel (`rgba(255,255,255,.03)`, border `#2a2233`, radius 22, soft pink shadow), max-width 340, full-width on mobile. Label "ENTER ROOM CODE", **4 code cells** (first two pink-tinted, last two yellow-tinted; live-fill from state), then a full-width **yellow** "Let's play →" button. Below: "Hosting tonight? Create a quiz free →".
- **How it works:** 3 flat cards (Enter the code / Answer fast / Claim the crown); grid stacks to 1 column < 680px.
- **Floating answer-tile motifs** in the background (hidden < 680px to reduce clutter).
- **Responsive rules** (media query, since inline can't): < 680px stacks the steps grid, hides the nav text link + motifs; < 420px shrinks the code cells. Everything else scales via `clamp()`.
- Map to a new public route (e.g. `src/pages/Home.tsx`) or the existing landing entry; wire the code cells + Join to the same code-verify path used by the player flow's code step.

## 2. Player flow — `Trivia Redesign.dc.html` (implement option `2a`)
Mobile journey inside a phone frame. Flat `#0d0f15` background (the old purple gradient + blur blobs were removed). Top bar: back chevron (hidden on step 1) + a step progress indicator (active = wide yellow pill w/ glow, inactive = dim dots).

- **Opening screen (mirrors the Home design):** crown + QUEEN/TRIVIA wordmark, tagline, the room-code join card (4 cells, yellow "Let's play →"), and "Hosting tonight? Create a quiz free →". → maps to `Gate.tsx` entry.
- **How it works ("Here's the deal"):** three rows, each a rounded card with an 8px colored left bar (pink/cyan/yellow) — "Enter the code", "Grab a name", "Go fast". CTA "Got it →" (pink).
- **Access code ("Magic word?"):** large centered uppercase input, 2px cyan border, radius 18. CTA "Check it →" (cyan). *Wire to existing `POST /api/auth/verify` (`Gate.tsx handleCodeSubmit`).*
- **Name + avatar ("You're in!"):** 4 color swatches (pink selected → yellow ring; cyan/purple/green) + name input. CTA "Enter the lobby →" (yellow). *Wire to `POST /api/auth/login`; on success route `/lobby`.*
- **Lobby:** "THE LOBBY" + "Playing as **Alex**"; three stat chips (LIVE / PLAYERS / TOP); live-game card (flat `rgba(255,0,128,.1)` tint + pink border, pulsing "● LIVE NOW", title, meta, avatar stack + "+8", "JOIN GAME →" yellow). *Reuse `useListGames`, `ActiveGameCard`, `useJoinGame`.*
- **Gameplay:** "QUESTION 4 / 12" + score pill "★ 230"; progress bar (pink→yellow fill, `glow`); category + points chips; question (800/22); 4 answer choices — default / correct (cyan border+glow+✓) / wrong (pink+✗) / dimmed. Footer hint → "SEE RESULTS →". *Reuse `useSubmitAnswer`. Sample: "Which river is traditionally considered the longest in the world?" → "The Nile".*
- **Final scores:** eyebrow "FINAL SCORES" + title + "12 questions · 6 players"; ranked list — winner pink-washed (flat `rgba(255,0,128,.12)`), a **"You"** row with `inset 2px 0 0 #ffe500` edge bar + yellow text, `tabular-nums` scores. Actions: "Play again" (yellow) + "Share". Sample: 1 Alex 340, 2 Jamie 290, 3 Sam 255, 4 **You** 210, 5 Riley 195.

Pages: `Gate.tsx` (onboarding), `Lobby.tsx`, `GamePlay.tsx`, `Results.tsx`. Avatar-stack cutout borders use the background color `#0d0f15`. Icons: use existing **lucide-react** (`ChevronLeft`, `CheckCircle2`, `XCircle`, `Star`, `Radio`) in place of the prototype's text glyphs.

## 3. Host console — `Host Console.dc.html`
Persistent **216px left rail** + routed views. Calmer "control-room" density (accents on data/status, not big color blocks). Panels `#0f1724`, rail/topbar `#0a1019`, border `#1b2740`.

- **Rail (persistent shell):** crown mark + "Queen Trivia" / "HOST CONSOLE" tag; nav = Games / Live game / Build a quiz / Results / Rooms & codes; host chip pinned bottom. Active item = pink left bar + `rgba(255,0,128,.12)` tint + white bold label + pink icon. Implement as the admin layout wrapper; active state from the current route.
- **Live game control (NEW):** topbar (pulsing `LIVE NOW`, title, `ROOM 4F7K` chip, player count, red **End game**). Left: question card (Q x/total, category+points chips, circular countdown ring, question, 4 answer rows w/ correct green-bordered + live tally bar/count) + transport bar (`‹ Prev · ⏸ Pause timer · ◎ Reveal answer · 🔒 Lock · Next question ›`, Next = pink). Right 300px: **Answered** card (pills dim until answered) + **Standings** top-6. Wire to the existing game/socket state that drives player `GamePlay`; if no host-advance endpoint exists, **stub + TODO, don't invent backend.** **Keep the view scrollable — do NOT force `100vh`** (answers must not overlap the transport bar on short screens).
- **Games:** header + All/Live/Drafts filter + **+ New quiz**; 3-col status cards (LIVE / DRAFT / SCHEDULED) + dashed New-quiz tile. Reuse existing list/create/delete hooks.
- **Build a quiz:** segmented **From categories ⟷ AI prompt** toggle over the EXISTING generation logic; count stepper + Easy/Med/Hard; editable generated-question list (correct option green + ✓, add/edit/reorder). Keep generation endpoints untouched.
- **Results:** 4 stat tiles (Players / Questions / Avg score / Avg correct) + full leaderboard (winner pink-washed, `correct/12`) + **Hardest questions** %-bars (derived client-side).
- **Rooms & codes:** active-room card (big cyan code `4F7K`, QR placeholder, Copy link / New code, joined count) + all-codes list with status pills (LIVE/SCHEDULED/CLOSED). Wire to existing access-code logic.

Confirm actual admin paths (likely `src/pages/admin/*` or `Host*`); map onto existing routes, keep current names.

---

## File index
- `Start Here.dc.html` — **hub**; links to everything.
- `Queen Trivia Home.dc.html` — **FINAL** home/landing page (responsive).
- `Trivia Redesign.dc.html` — **FINAL** player flow; implement **option `2a`**. Turn-1 options (`1a`–`1e`) are reference only.
- `Host Console.dc.html` — **FINAL** host dashboard (interactive; click the rail).
- `Queen Trivia Home Variations.dc.html` — home explorations: layouts (1a/1b/1c), palettes (2a/2b/2c), pink+yellow set (3a/3b/3c). **3b chosen.** Reference only.
- `Host Dashboard.dc.html` — host layout explorations (1a sidebar chosen / 1b broadcast / 1c mission-control). Reference only.
- `screens/` — reference screenshots of the player flow.

---

## Paste-ready Replit prompts

### Player flow + home
```
Rebrand and restyle the trivia app to "Queen Trivia" per the attached prototypes (Queen Trivia Home.dc.html + Trivia Redesign.dc.html option 2a). UI/UX + rename ONLY — keep all data fetching, auth, sockets, routing, and API hooks intact.

Brand: flat near-black bg #0d0f15 (NO gradient hero), accents pink #ff0080 (primary/brand), yellow #ffe500 (CTA/score), cyan #00ddff (codes/correct). Manrope. Logo = flat inline-SVG crown (pink body path "M8,66 L8,26 L30,46 L50,14 L70,46 L92,26 L92,66 Z" + base band, yellow jewel circles) — no gradients/glow on the mark. Stacked wordmark QUEEN (yellow) / TRIVIA (pink).

1. New responsive Home/landing: nav (crown + Queen Trivia, How it works, Host sign in); hero crown + big QUEEN/TRIVIA wordmark + tagline "Enter the code. Answer fast. Take the throne."; a bordered join card with label "ENTER ROOM CODE", 4 room-code cells (2 pink, 2 yellow tint) and a yellow "Let's play" button; "Hosting tonight? Create a quiz free"; a 3-card "how it works". Use clamp() for fluid type and a media query so <680px stacks the steps and hides the nav text link + bg motifs; <420px shrinks code cells. Wire the code + Join to the existing code-verify path.

2. Restyle the player flow (Gate/Lobby/GamePlay/Results) on flat #0d0f15: opening Gate screen mirrors the Home (crown + wordmark + room-code join card). Then how-it-works rows, cyan code step (wire to existing verify), name+avatar step (wire to existing login → /lobby), lobby (stat chips + flat pink-tinted live-game card + JOIN), gameplay (pink→yellow progress, answer states: correct cyan+✓ / wrong pink+✗ / dimmed), final scores (winner pink-washed, "You" row with yellow left edge bar, tabular-nums). Avatar-stack cutout borders = #0d0f15. Use lucide-react icons. Keep all existing hooks and loading/error/toast handling.
```

### Host console
```
Restyle the host/admin dashboard to match Host Console.dc.html and the Queen Trivia brand. UI/UX ONLY — do not change data fetching, auth, sockets, quiz generation, or delete logic. Reuse existing Tailwind tokens, shadcn/ui, Manrope, wouter routes, hooks.

Palette (calmer control-room): app bg #0a0c12, panels #0f1724, rail/topbar #0a1019, border #1b2740. Accents by meaning — pink #ff0080 = live/primary, cyan #00ddff = codes/info, yellow #ffe500 = timer/go-live-secondary, green #35d07f = answered/correct, red #ff6b6b = destructive. Numbers in mono + tabular-nums.

1. Wrap admin pages in a 216px persistent left rail: crown mark + "Queen Trivia" / "HOST CONSOLE", nav = Games / Live game / Build a quiz / Results / Rooms & codes, host chip bottom. Active item = pink left bar + rgba(255,0,128,.12) tint. Drive active state from the current route.

2. NEW "Live game control" view: topbar (pulsing LIVE badge, title, ROOM code chip, player count, red End game). Left: question card (Q x/total, category+points chips, circular countdown, question, 4 answer rows with correct = green border + live tally bar/count) + transport bar (Prev, Pause timer, Reveal answer, Lock, Next = pink). Right 300px: "Answered X/N" with player pills that dim until they answer + live Standings top-6. Wire to the existing game/socket state that powers player GamePlay; if there's no host-advance endpoint, stub + TODO — do not invent backend. Keep the view SCROLLABLE; do NOT force 100vh (answers must not overlap the transport bar).

3. Games list: header + All/Live/Drafts filter + New quiz; 3-col status cards (LIVE/DRAFT/SCHEDULED) with existing edit/delete/go-live actions.

4. Build a quiz: segmented "From categories / AI prompt" toggle over EXISTING generation logic, count stepper + difficulty, editable generated-question list (correct = green, add/edit/reorder). Keep generation endpoints untouched.

5. Results: stat tiles (players/questions/avg score/avg correct) + full leaderboard (winner pink-washed, correct/total) + "Hardest questions" %-bars from existing answer data.

6. Rooms & codes: active-room card (big cyan code, QR, copy/rotate, joined count) + all-codes list with status pills. Wire to existing access-code logic.

Match spacing/radii/typography to the prototype. Keep existing loading/error/toast handling.
```
